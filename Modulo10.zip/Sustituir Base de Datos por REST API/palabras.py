palabras = [
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},
    {'nombre': 'portátil', 'significado': 800},

]